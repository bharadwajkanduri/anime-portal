export default async function handler(req, res) {
  // Implement Stripe webhook handling here in production
  res.status(200).send('ok')
}
